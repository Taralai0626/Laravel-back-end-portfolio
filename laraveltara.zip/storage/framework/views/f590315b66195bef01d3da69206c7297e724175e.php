
<?= view('layout.header') ?>

<section class="w3-padding">
        
    <h2 class="w3-text-blue">About Me!</h2>

    <?php if: ?><?php echo e($about->image); ?>

        <div class="w3-margin-top">
            <img src="<?= asset('storage/'.$about->image) ?>" width="400">
        </div>
    <?php endif; ?>

    <p><?php echo e($about->content); ?> </p>

    <h3>My Skills</h3>

    <ul>
        <li>PHP</li>
        <li>Laravel</li>
        <li>MySQL</li>
    </ul>

</section>

<hr>

<?php echo $__env->yieldContent('content'); ?>

<hr>

<section class="w3-padding">

    <h2 class="w3-text-blue">Contact Me</h2>

    <p>
        Phone: 111.222.3333
        <br>
        Email: <a href="mailto:email@address.com">email@address.com</a>
    </p>

</section>

<?= view('layout.footer') ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Tara-Sean-lavarelAssign2/resources/views/layout/frontend.blade.php ENDPATH**/ ?>